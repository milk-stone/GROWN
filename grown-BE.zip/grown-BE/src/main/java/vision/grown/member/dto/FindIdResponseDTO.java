package vision.grown.member.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class FindIdResponseDTO {
    private String email;
}
