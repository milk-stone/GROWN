package vision.grown.member;

public enum MemberType {
    NORMAL,VIP
}
