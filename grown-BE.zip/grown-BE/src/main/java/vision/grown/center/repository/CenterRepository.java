package vision.grown.center.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vision.grown.center.Center;

public interface CenterRepository extends JpaRepository<Center,Long> {
}
