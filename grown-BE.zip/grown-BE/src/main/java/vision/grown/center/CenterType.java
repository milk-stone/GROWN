package vision.grown.center;

public enum CenterType {
    HOSPITAL,SCHOOL,CHILD
}
