package vision.grown.funding;

public enum FundingStatus {
    FUND,COMP
}
