package vision.grown.product;

public enum MeasurementUnit {
    KG,G,L,mL
}
