package vision.grown.product;

public enum ProductType {
    POTATO,CARROT,TOMATO,APPLE
}
