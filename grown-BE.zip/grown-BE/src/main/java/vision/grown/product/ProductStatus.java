package vision.grown.product;

public enum ProductStatus {
    SALE,COMP
}
