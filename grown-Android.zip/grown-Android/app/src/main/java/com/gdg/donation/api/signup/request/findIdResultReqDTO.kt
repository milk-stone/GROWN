package com.gdg.donation.api.signup.request

data class findIdResultReqDTO(
    val name: String,
    val phoneNum: String
)
