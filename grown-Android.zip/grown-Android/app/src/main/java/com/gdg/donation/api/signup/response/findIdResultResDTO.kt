package com.gdg.donation.api.signup.response

data class findIdResultResDTO(
    val email: String
)
