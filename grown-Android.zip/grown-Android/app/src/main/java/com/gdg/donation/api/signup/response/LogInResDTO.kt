package com.gdg.donation.api.signup.response

data class LogInResDTO(
    val message: String
)
