package com.gdg.donation.api.signup.request

data class ResetPasswordReqDTO(
    val email: String,
    val password: String
)
