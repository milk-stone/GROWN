package com.gdg.donation.farmproducts

import androidx.fragment.app.Fragment

class FarmProductsWritingDefault : Fragment(){

}