package com.gdg.donation.api.signup.request

data class LogInReqDTO(
    val email: String,
    val password: String
)
